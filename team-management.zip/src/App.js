import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { AuthProvider } from './contexts/AuthContext';
import { AppProvider } from './contexts/AppContext';
import ProtectedRoute from './components/Shared/ProtectedRoute';
import AppLayout from './components/Shared/AppLayout';

import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import UsersPage from './pages/UsersPage';
import TasksPage from './pages/TasksPage';
import LeavesPage from './pages/LeavesPage';
import ProfilePage from './pages/ProfilePage';
import UnauthorizedPage from './pages/UnauthorizedPage';

import { ROUTES, ROLES } from './utils/constants';

const theme = createTheme({
  palette: {
    primary: { main: '#1976d2' },
    secondary: { main: '#9c27b0' },
    background: { default: '#f5f7fb' },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
  },
  shape: { borderRadius: 8 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { textTransform: 'none', fontWeight: 600 },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: { boxShadow: 'none' },
      },
    },
  },
});

const LayoutRoute = ({ children }) => (
  <AppLayout>{children}</AppLayout>
);

const App = () => (
  <ThemeProvider theme={theme}>
    <CssBaseline />
    <AuthProvider>
      <AppProvider>
        <BrowserRouter>
          <Routes>
            <Route path={ROUTES.LOGIN} element={<LoginPage />} />
            <Route path={ROUTES.UNAUTHORIZED} element={<UnauthorizedPage />} />

            <Route path={ROUTES.DASHBOARD} element={
              <ProtectedRoute>
                <LayoutRoute><DashboardPage /></LayoutRoute>
              </ProtectedRoute>
            } />

            <Route path={ROUTES.USERS} element={
              <ProtectedRoute roles={[ROLES.ADMIN]}>
                <LayoutRoute><UsersPage /></LayoutRoute>
              </ProtectedRoute>
            } />

            <Route path={ROUTES.TASKS} element={
              <ProtectedRoute roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.ASSOCIATE]}>
                <LayoutRoute><TasksPage /></LayoutRoute>
              </ProtectedRoute>
            } />

            <Route path={ROUTES.LEAVES} element={
              <ProtectedRoute roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.ASSOCIATE]}>
                <LayoutRoute><LeavesPage /></LayoutRoute>
              </ProtectedRoute>
            } />

            <Route path={ROUTES.PROFILE} element={
              <ProtectedRoute>
                <LayoutRoute><ProfilePage /></LayoutRoute>
              </ProtectedRoute>
            } />

            <Route path="/" element={<Navigate to={ROUTES.DASHBOARD} replace />} />
            <Route path="*" element={<Navigate to={ROUTES.DASHBOARD} replace />} />
          </Routes>
        </BrowserRouter>
        <ToastContainer position="top-right" autoClose={3000} hideProgressBar={false} newestOnTop closeOnClick pauseOnHover />
      </AppProvider>
    </AuthProvider>
  </ThemeProvider>
);

export default App;
