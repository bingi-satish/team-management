import { toast } from 'react-toastify';

const useNotification = () => {
  const success = (msg) => toast.success(msg, { position: 'top-right', autoClose: 3000 });
  const error = (msg) => toast.error(msg, { position: 'top-right', autoClose: 4000 });
  const info = (msg) => toast.info(msg, { position: 'top-right', autoClose: 3000 });
  const warning = (msg) => toast.warning(msg, { position: 'top-right', autoClose: 3500 });
  return { success, error, info, warning };
};

export default useNotification;
