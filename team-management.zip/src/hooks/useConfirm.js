import { useState, useCallback } from 'react';

const useConfirm = () => {
  const [state, setState] = useState({ open: false, title: '', message: '', resolve: null });

  const confirm = useCallback((title, message) =>
    new Promise((resolve) => setState({ open: true, title, message, resolve })),
  []);

  const handleClose = useCallback((result) => {
    state.resolve?.(result);
    setState({ open: false, title: '', message: '', resolve: null });
  }, [state]);

  return { confirmState: state, confirm, handleClose };
};

export default useConfirm;
