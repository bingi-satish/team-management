import React, { createContext, useContext, useEffect, useReducer, useCallback } from 'react';
import authService from '../services/authService';
import LoadingScreen from '../components/Shared/LoadingScreen';

const AuthContext = createContext(null);

const initialState = {
  user: null,
  token: null,
  loading: true,   // true until MSAL redirect promise resolves
  error: null,
};

const authReducer = (state, action) => {
  switch (action.type) {
    case 'INIT_DONE':
      return { ...state, user: action.user, token: action.token, loading: false, error: null };
    case 'LOGOUT':
      return { ...initialState, loading: false };
    case 'SET_ERROR':
      return { ...state, error: action.error, loading: false };
    default:
      return state;
  }
};

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  useEffect(() => {
    // Must run once on mount — resolves the MSAL redirect response
    authService.initialize()
      .then((user) => {
        const token = authService.getToken();
        dispatch({ type: 'INIT_DONE', user: user || null, token: token || null });
      })
      .catch((err) => {
        dispatch({ type: 'SET_ERROR', error: err.message });
      });
  }, []);

  const loginWithSSO = useCallback(() => {
    authService.loginWithSSO(); // triggers a full-page redirect to ADFS / Entra
  }, []);

  const logout = useCallback(() => {
    authService.logout();
    dispatch({ type: 'LOGOUT' });
  }, []);

  const hasRole = useCallback((roles) => {
    if (!state.user) return false;
    const allowed = Array.isArray(roles) ? roles : [roles];
    return allowed.includes(state.user.role);
  }, [state.user]);

  const clearError = useCallback(() => dispatch({ type: 'SET_ERROR', error: null }), []);

  // Block the whole app until MSAL has resolved the redirect promise
  if (state.loading) return <LoadingScreen message="Authenticating via Windows SSO..." />;

  return (
    <AuthContext.Provider value={{ ...state, loginWithSSO, logout, hasRole, clearError }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
