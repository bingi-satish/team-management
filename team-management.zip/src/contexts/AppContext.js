import React, { createContext, useContext, useReducer, useCallback } from 'react';
import userService from '../services/userService';
import taskService from '../services/taskService';
import leaveService from '../services/leaveService';

const AppContext = createContext(null);

const initialState = {
  users: [],
  tasks: [],
  leaves: [],
  notifications: [],
  loading: { users: false, tasks: false, leaves: false },
  errors: { users: null, tasks: null, leaves: null },
};

const appReducer = (state, action) => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: { ...state.loading, [action.key]: action.value } };
    case 'SET_ERROR':
      return { ...state, errors: { ...state.errors, [action.key]: action.value } };
    case 'SET_USERS':
      return { ...state, users: action.data };
    case 'SET_TASKS':
      return { ...state, tasks: action.data };
    case 'SET_LEAVES':
      return { ...state, leaves: action.data };
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.data] };
    case 'UPDATE_USER':
      return { ...state, users: state.users.map((u) => (u.id === action.data.id ? action.data : u)) };
    case 'DELETE_USER':
      return { ...state, users: state.users.filter((u) => u.id !== action.id) };
    case 'ADD_TASK':
      return { ...state, tasks: [...state.tasks, action.data] };
    case 'UPDATE_TASK':
      return { ...state, tasks: state.tasks.map((t) => (t.id === action.data.id ? action.data : t)) };
    case 'DELETE_TASK':
      return { ...state, tasks: state.tasks.filter((t) => t.id !== action.id) };
    case 'ADD_LEAVE':
      return { ...state, leaves: [...state.leaves, action.data] };
    case 'UPDATE_LEAVE':
      return { ...state, leaves: state.leaves.map((l) => (l.id === action.data.id ? action.data : l)) };
    case 'DELETE_LEAVE':
      return { ...state, leaves: state.leaves.filter((l) => l.id !== action.id) };
    case 'ADD_NOTIFICATION':
      return { ...state, notifications: [action.data, ...state.notifications].slice(0, 20) };
    case 'CLEAR_NOTIFICATIONS':
      return { ...state, notifications: [] };
    default:
      return state;
  }
};

export const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  const fetchUsers = useCallback(async () => {
    dispatch({ type: 'SET_LOADING', key: 'users', value: true });
    try {
      const data = await userService.getAll();
      dispatch({ type: 'SET_USERS', data });
    } catch (e) {
      dispatch({ type: 'SET_ERROR', key: 'users', value: e.message });
    } finally {
      dispatch({ type: 'SET_LOADING', key: 'users', value: false });
    }
  }, []);

  const fetchTasks = useCallback(async () => {
    dispatch({ type: 'SET_LOADING', key: 'tasks', value: true });
    try {
      const data = await taskService.getAll();
      dispatch({ type: 'SET_TASKS', data });
    } catch (e) {
      dispatch({ type: 'SET_ERROR', key: 'tasks', value: e.message });
    } finally {
      dispatch({ type: 'SET_LOADING', key: 'tasks', value: false });
    }
  }, []);

  const fetchLeaves = useCallback(async () => {
    dispatch({ type: 'SET_LOADING', key: 'leaves', value: true });
    try {
      const data = await leaveService.getAll();
      dispatch({ type: 'SET_LEAVES', data });
    } catch (e) {
      dispatch({ type: 'SET_ERROR', key: 'leaves', value: e.message });
    } finally {
      dispatch({ type: 'SET_LOADING', key: 'leaves', value: false });
    }
  }, []);

  const createUser = useCallback(async (data) => {
    const user = await userService.create(data);
    dispatch({ type: 'ADD_USER', data: user });
    dispatch({ type: 'ADD_NOTIFICATION', data: { id: Date.now(), message: `User "${user.name}" created.`, type: 'success' } });
    return user;
  }, []);

  const updateUser = useCallback(async (id, data) => {
    const user = await userService.update(id, data);
    dispatch({ type: 'UPDATE_USER', data: user });
    return user;
  }, []);

  const deleteUser = useCallback(async (id) => {
    await userService.delete(id);
    dispatch({ type: 'DELETE_USER', id });
  }, []);

  const createTask = useCallback(async (data) => {
    const task = await taskService.create(data);
    dispatch({ type: 'ADD_TASK', data: task });
    dispatch({ type: 'ADD_NOTIFICATION', data: { id: Date.now(), message: `Task "${task.title}" created.`, type: 'success' } });
    return task;
  }, []);

  const updateTask = useCallback(async (id, data) => {
    const task = await taskService.update(id, data);
    dispatch({ type: 'UPDATE_TASK', data: task });
    return task;
  }, []);

  const deleteTask = useCallback(async (id) => {
    await taskService.delete(id);
    dispatch({ type: 'DELETE_TASK', id });
  }, []);

  const createLeave = useCallback(async (data) => {
    const leave = await leaveService.create(data);
    dispatch({ type: 'ADD_LEAVE', data: leave });
    dispatch({ type: 'ADD_NOTIFICATION', data: { id: Date.now(), message: 'Leave request submitted.', type: 'info' } });
    return leave;
  }, []);

  const reviewLeave = useCallback(async (id, status, reviewerId, comments) => {
    const leave = await leaveService.review(id, status, reviewerId, comments);
    dispatch({ type: 'UPDATE_LEAVE', data: leave });
    dispatch({ type: 'ADD_NOTIFICATION', data: { id: Date.now(), message: `Leave ${status.toLowerCase()}.`, type: status === 'Approved' ? 'success' : 'warning' } });
    return leave;
  }, []);

  const cancelLeave = useCallback(async (id) => {
    await leaveService.delete(id);
    dispatch({ type: 'DELETE_LEAVE', id });
  }, []);

  return (
    <AppContext.Provider value={{
      ...state,
      fetchUsers, fetchTasks, fetchLeaves,
      createUser, updateUser, deleteUser,
      createTask, updateTask, deleteTask,
      createLeave, reviewLeave, cancelLeave,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
