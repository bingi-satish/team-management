import { TASK_PRIORITY, TASK_STATUS, LEAVE_STATUS, PERMISSIONS } from './constants';

export const formatDate = (dateStr) => {
  if (!dateStr) return '-';
  return new Date(dateStr).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
};

export const getDaysUntilDue = (dueDate) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(dueDate);
  const diff = Math.ceil((due - today) / (1000 * 60 * 60 * 24));
  return diff;
};

export const getTaskDueStatus = (dueDate, status) => {
  if (status === TASK_STATUS.COMPLETED || status === TASK_STATUS.CANCELLED) return 'completed';
  const days = getDaysUntilDue(dueDate);
  if (days < 0) return 'overdue';
  if (days <= 2) return 'due-soon';
  return 'on-track';
};

export const getPriorityColor = (priority) => {
  const map = {
    [TASK_PRIORITY.CRITICAL]: 'error',
    [TASK_PRIORITY.HIGH]: 'warning',
    [TASK_PRIORITY.MEDIUM]: 'info',
    [TASK_PRIORITY.LOW]: 'success',
  };
  return map[priority] || 'default';
};

export const getStatusColor = (status) => {
  const map = {
    [TASK_STATUS.COMPLETED]: 'success',
    [TASK_STATUS.IN_PROGRESS]: 'info',
    [TASK_STATUS.PENDING]: 'warning',
    [TASK_STATUS.CANCELLED]: 'error',
    [LEAVE_STATUS.APPROVED]: 'success',
    [LEAVE_STATUS.REJECTED]: 'error',
    [LEAVE_STATUS.PENDING]: 'warning',
    Active: 'success',
    Inactive: 'error',
  };
  return map[status] || 'default';
};

export const generateId = (items) =>
  items.length > 0 ? Math.max(...items.map((i) => i.id)) + 1 : 1;

export const filterTasks = (tasks, filters) => {
  return tasks.filter((t) => {
    if (filters.status && t.status !== filters.status) return false;
    if (filters.priority && t.priority !== filters.priority) return false;
    if (filters.assignedTo && t.assignedTo !== filters.assignedTo) return false;
    if (filters.project && !t.project.toLowerCase().includes(filters.project.toLowerCase())) return false;
    if (filters.search && !t.title.toLowerCase().includes(filters.search.toLowerCase())) return false;
    return true;
  });
};

export const getLeaveBalance = (leaves, userId) => {
  const approved = leaves.filter((l) => l.userId === userId && l.status === LEAVE_STATUS.APPROVED);
  const used = { Annual: 0, Sick: 0, Casual: 0 };
  approved.forEach((l) => { if (used[l.type] !== undefined) used[l.type] += l.days; });
  return { Annual: Math.max(0, 20 - used.Annual), Sick: Math.max(0, 10 - used.Sick), Casual: Math.max(0, 5 - used.Casual) };
};

export const hasPermission = (userRole, permission) =>
  PERMISSIONS[userRole]?.includes(permission) ?? false;

export const mockSSOToken = (user) => ({
  access_token: btoa(JSON.stringify({ id: user.id, email: user.email, role: user.role, exp: Date.now() + 3600000 })),
  token_type: 'Bearer',
  expires_in: 3600,
});

export const decodeToken = (token) => {
  try {
    return JSON.parse(atob(token));
  } catch {
    return null;
  }
};
