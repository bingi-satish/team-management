export const ROLES = {
  ADMIN: 'Admin',
  MANAGER: 'Manager',
  ASSOCIATE: 'Associate',
};

export const TASK_STATUS = {
  PENDING: 'Pending',
  IN_PROGRESS: 'In Progress',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled',
};

export const TASK_PRIORITY = {
  LOW: 'Low',
  MEDIUM: 'Medium',
  HIGH: 'High',
  CRITICAL: 'Critical',
};

export const LEAVE_STATUS = {
  PENDING: 'Pending',
  APPROVED: 'Approved',
  REJECTED: 'Rejected',
};

export const LEAVE_TYPES = ['Annual', 'Sick', 'Casual', 'Maternity', 'Paternity', 'Unpaid'];

export const USER_STATUS = {
  ACTIVE: 'Active',
  INACTIVE: 'Inactive',
};

export const DEPARTMENTS = ['IT', 'Engineering', 'Design', 'HR', 'Finance', 'Marketing', 'Operations'];

export const ROUTES = {
  LOGIN: '/login',
  DASHBOARD: '/dashboard',
  USERS: '/users',
  TASKS: '/tasks',
  LEAVES: '/leaves',
  PROFILE: '/profile',
  UNAUTHORIZED: '/unauthorized',
};

export const PERMISSIONS = {
  [ROLES.ADMIN]: ['manage_users', 'manage_tasks', 'manage_leaves', 'view_all', 'assign_tasks', 'approve_leaves'],
  [ROLES.MANAGER]: ['view_team', 'assign_tasks', 'approve_leaves', 'manage_tasks', 'view_reports'],
  [ROLES.ASSOCIATE]: ['view_own_tasks', 'update_task_status', 'request_leave', 'view_own_leaves'],
};
