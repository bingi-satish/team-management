import initialLeaves from '../data/leaves.json';
import { storage } from '../utils/storage';
import { generateId } from '../utils/helpers';

const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

const getLeaves = () => {
  const stored = storage.get('leaves');
  if (stored && stored.length > 0) return stored;
  storage.set('leaves', initialLeaves);
  return initialLeaves;
};
const saveLeaves = (leaves) => storage.set('leaves', [...leaves]);

const leaveService = {
  getAll: async () => {
    await delay();
    return getLeaves();
  },

  getByUser: async (userId) => {
    await delay();
    return getLeaves().filter((l) => l.userId === userId);
  },

  getForTeam: async (memberIds) => {
    await delay();
    return getLeaves().filter((l) => memberIds.includes(l.userId));
  },

  getPending: async () => {
    await delay();
    return getLeaves().filter((l) => l.status === 'Pending');
  },

  create: async (leaveData) => {
    await delay();
    const leaves = getLeaves();
    const start = new Date(leaveData.startDate);
    const end = new Date(leaveData.endDate);
    if (end < start) throw new Error('End date must be after start date.');
    const days = Math.ceil((end - start) / 86400000) + 1;
    const overlap = leaves.find(
      (l) =>
        l.userId === leaveData.userId &&
        l.status !== 'Rejected' &&
        new Date(l.startDate) <= end &&
        new Date(l.endDate) >= start
    );
    if (overlap) throw new Error('You already have a leave request for these dates.');
    const newLeave = {
      ...leaveData,
      id: generateId(leaves),
      days,
      status: 'Pending',
      appliedOn: new Date().toISOString().split('T')[0],
      reviewedBy: null,
      reviewedOn: null,
      comments: '',
    };
    saveLeaves([...leaves, newLeave]);
    return { ...newLeave };
  },

  review: async (id, status, reviewerId, comments = '') => {
    await delay();
    const leaves = getLeaves();
    const idx = leaves.findIndex((l) => l.id === id);
    if (idx === -1) throw new Error('Leave request not found.');
    if (leaves[idx].status !== 'Pending') throw new Error('Leave already reviewed.');
    const updated = {
      ...leaves[idx],
      status,
      reviewedBy: reviewerId,
      reviewedOn: new Date().toISOString().split('T')[0],
      comments,
    };
    const newLeaves = leaves.map((l) => (l.id === id ? updated : l));
    saveLeaves(newLeaves);
    return { ...updated };
  },

  delete: async (id) => {
    await delay();
    const leaves = getLeaves();
    const leave = leaves.find((l) => l.id === id);
    if (!leave) throw new Error('Leave not found.');
    if (leave.status !== 'Pending') throw new Error('Only pending leaves can be cancelled.');
    saveLeaves(leaves.filter((l) => l.id !== id));
    return { success: true };
  },

  getStats: async (userId = null) => {
    await delay(100);
    const leaves = userId ? getLeaves().filter((l) => l.userId === userId) : getLeaves();
    return {
      total: leaves.length,
      pending: leaves.filter((l) => l.status === 'Pending').length,
      approved: leaves.filter((l) => l.status === 'Approved').length,
      rejected: leaves.filter((l) => l.status === 'Rejected').length,
    };
  },
};

export default leaveService;
