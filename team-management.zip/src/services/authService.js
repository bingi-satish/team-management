import { PublicClientApplication, InteractionRequiredAuthError } from '@azure/msal-browser';
import usersData from '../data/users.json';
import { storage } from '../utils/storage';

// ---------------------------------------------------------------------------
// MSAL configuration — update these values in .env for your ADFS / Entra ID
// ---------------------------------------------------------------------------
const msalConfig = {
  auth: {
    clientId: process.env.REACT_APP_ADFS_CLIENT_ID || 'your-client-id',
    authority: process.env.REACT_APP_ADFS_AUTHORITY || 'https://login.microsoftonline.com/your-tenant-id',
    redirectUri: process.env.REACT_APP_ADFS_REDIRECT_URI || window.location.origin,
    postLogoutRedirectUri: window.location.origin,
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: 'localStorage',
    storeAuthStateInCookie: true, // required for IE11 / Edge legacy
  },
};

const loginRequest = {
  scopes: ['openid', 'profile', 'email', 'User.Read'],
};

// Singleton MSAL instance
export const msalInstance = new PublicClientApplication(msalConfig);

// ---------------------------------------------------------------------------
// Map an MSAL account claim to a local user record from users.json
// Falls back to the first Admin if no email match (dev convenience)
// ---------------------------------------------------------------------------
const resolveUser = (account) => {
  const email = account?.username || account?.idTokenClaims?.preferred_username || '';
  const match = usersData.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (match) {
    const { password: _pw, ...safe } = match;
    return safe;
  }
  // Fallback for dev: return the admin user so the app is always navigable
  const { password: _pw, ...admin } = usersData[0];
  return admin;
};

const authService = {
  // Call once at app startup — handles redirect response
  initialize: async () => {
    await msalInstance.initialize();
    const response = await msalInstance.handleRedirectPromise();
    if (response?.account) {
      msalInstance.setActiveAccount(response.account);
      const user = resolveUser(response.account);
      storage.set('user', user);
      storage.set('token', response.accessToken || response.idToken);
      return user;
    }
    // Restore previously active account on page refresh
    const accounts = msalInstance.getAllAccounts();
    if (accounts.length > 0) {
      msalInstance.setActiveAccount(accounts[0]);
      const user = resolveUser(accounts[0]);
      storage.set('user', user);
      return user;
    }
    return null;
  },

  // Redirect to Microsoft / ADFS login page
  loginWithSSO: () => {
    msalInstance.loginRedirect(loginRequest);
  },

  // Acquire token silently; fall back to redirect if interaction required
  getAccessToken: async () => {
    const account = msalInstance.getActiveAccount();
    if (!account) return null;
    try {
      const result = await msalInstance.acquireTokenSilent({ ...loginRequest, account });
      storage.set('token', result.accessToken);
      return result.accessToken;
    } catch (err) {
      if (err instanceof InteractionRequiredAuthError) {
        msalInstance.acquireTokenRedirect({ ...loginRequest, account });
      }
      return null;
    }
  },

  logout: () => {
    storage.clear();
    const account = msalInstance.getActiveAccount();
    msalInstance.logoutRedirect({ account });
  },

  getCurrentUser: () => storage.get('user'),

  getToken: () => storage.get('token'),

  isAuthenticated: () => {
    const accounts = msalInstance.getAllAccounts();
    return accounts.length > 0;
  },
};

export default authService;
