import initialTasks from '../data/tasks.json';
import { storage } from '../utils/storage';
import { generateId } from '../utils/helpers';

const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

const getTasks = () => {
  const stored = storage.get('tasks');
  if (stored && stored.length > 0) return stored;
  storage.set('tasks', initialTasks);
  return initialTasks;
};
const saveTasks = (tasks) => storage.set('tasks', [...tasks]);

const taskService = {
  getAll: async () => {
    await delay();
    return getTasks();
  },

  getById: async (id) => {
    await delay();
    const task = getTasks().find((t) => t.id === id);
    if (!task) throw new Error('Task not found.');
    return task;
  },

  getByUser: async (userId) => {
    await delay();
    return getTasks().filter((t) => t.assignedTo === userId);
  },

  getByAssigner: async (assignerId) => {
    await delay();
    return getTasks().filter((t) => t.assignedBy === assignerId);
  },

  getForTeam: async (memberIds) => {
    await delay();
    return getTasks().filter((t) => memberIds.includes(t.assignedTo));
  },

  create: async (taskData) => {
    await delay();
    const tasks = getTasks();
    const newTask = {
      ...taskData,
      id: generateId(tasks),
      status: taskData.status || 'Pending',
      createdAt: new Date().toISOString().split('T')[0],
    };
    saveTasks([...tasks, newTask]);
    return { ...newTask };
  },

  update: async (id, updates) => {
    await delay();
    const tasks = getTasks();
    const idx = tasks.findIndex((t) => t.id === id);
    if (idx === -1) throw new Error('Task not found.');
    const updated = { ...tasks[idx], ...updates };
    const newTasks = tasks.map((t) => (t.id === id ? updated : t));
    saveTasks(newTasks);
    return { ...updated };
  },

  delete: async (id) => {
    await delay();
    const tasks = getTasks();
    if (!tasks.find((t) => t.id === id)) throw new Error('Task not found.');
    saveTasks(tasks.filter((t) => t.id !== id));
    return { success: true };
  },

  getStats: async (userId = null) => {
    await delay(100);
    const tasks = userId ? getTasks().filter((t) => t.assignedTo === userId) : getTasks();
    return {
      total: tasks.length,
      pending: tasks.filter((t) => t.status === 'Pending').length,
      inProgress: tasks.filter((t) => t.status === 'In Progress').length,
      completed: tasks.filter((t) => t.status === 'Completed').length,
      overdue: tasks.filter((t) => {
        const days = Math.ceil((new Date(t.dueDate) - new Date()) / 86400000);
        return days < 0 && t.status !== 'Completed' && t.status !== 'Cancelled';
      }).length,
    };
  },
};

export default taskService;
