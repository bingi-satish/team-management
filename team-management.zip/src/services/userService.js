import initialUsers from '../data/users.json';
import { storage } from '../utils/storage';
import { generateId } from '../utils/helpers';

const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

// Always read from storage (with passwords preserved); fall back to seed data
const getUsers = () => {
  const stored = storage.get('users');
  // If stored list exists and has same or more entries than seed, use it
  if (stored && stored.length > 0) return stored;
  // First time: seed storage from JSON so all subsequent writes go to storage
  storage.set('users', initialUsers);
  return initialUsers;
};

const saveUsers = (users) => storage.set('users', users);

// Strip password before exposing to UI
const safe = (user) => { const { password: _pw, ...u } = user; return u; };

const userService = {
  getAll: async () => {
    await delay();
    return getUsers().map(safe);
  },

  getById: async (id) => {
    await delay();
    const user = getUsers().find((u) => u.id === id);
    if (!user) throw new Error('User not found.');
    return safe(user);
  },

  getByRole: async (role) => {
    await delay();
    return getUsers().filter((u) => u.role === role).map(safe);
  },

  getTeamMembers: async (managerId) => {
    await delay();
    return getUsers().filter((u) => u.managerId === managerId).map(safe);
  },

  create: async (userData) => {
    await delay();
    const users = getUsers();
    if (users.find((u) => u.email.toLowerCase() === userData.email.toLowerCase()))
      throw new Error('Email already exists.');
    const newUser = {
      ...userData,
      id: generateId(users),
      status: userData.status || 'Active',
      avatar: userData.name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2),
      joinDate: userData.joinDate || new Date().toISOString().split('T')[0],
      // Preserve password from form or set default; SSO users won't use this
      password: userData.password || 'changeme123',
    };
    saveUsers([...users, newUser]);
    return safe(newUser);
  },

  update: async (id, updates) => {
    await delay();
    const users = getUsers();
    const idx = users.findIndex((u) => u.id === id);
    if (idx === -1) throw new Error('User not found.');
    if (updates.email) {
      const dup = users.find((u) => u.email.toLowerCase() === updates.email.toLowerCase() && u.id !== id);
      if (dup) throw new Error('Email already exists.');
    }
    // Merge updates; never overwrite password unless explicitly provided
    const { password: newPwd, ...safeUpdates } = updates;
    users[idx] = { ...users[idx], ...safeUpdates, ...(newPwd ? { password: newPwd } : {}) };
    saveUsers([...users]);
    return safe(users[idx]);
  },

  delete: async (id) => {
    await delay();
    const users = getUsers();
    if (!users.find((u) => u.id === id)) throw new Error('User not found.');
    saveUsers(users.filter((u) => u.id !== id));
    return { success: true };
  },

  updatePassword: async (id, currentPassword, newPassword) => {
    await delay();
    const users = getUsers();
    const idx = users.findIndex((u) => u.id === id);
    if (idx === -1) throw new Error('User not found.');
    if (users[idx].password !== currentPassword) throw new Error('Current password is incorrect.');
    users[idx] = { ...users[idx], password: newPassword };
    saveUsers([...users]);
    return safe(users[idx]);
  },

  resetData: () => {
    storage.set('users', initialUsers);
  },
};

export default userService;
