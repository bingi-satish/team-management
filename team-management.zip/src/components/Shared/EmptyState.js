import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import InboxIcon from '@mui/icons-material/Inbox';

const EmptyState = ({ title = 'No data found', subtitle, action, actionLabel }) => (
  <Box sx={{ textAlign: 'center', py: 8, px: 2 }}>
    <InboxIcon sx={{ fontSize: 64, color: 'text.disabled', mb: 2 }} />
    <Typography variant="h6" fontWeight={600} color="text.secondary">{title}</Typography>
    {subtitle && <Typography variant="body2" color="text.disabled" sx={{ mt: 1 }}>{subtitle}</Typography>}
    {action && (
      <Button variant="contained" onClick={action} sx={{ mt: 3 }}>{actionLabel}</Button>
    )}
  </Box>
);

export default EmptyState;
