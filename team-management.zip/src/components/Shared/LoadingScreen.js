import React from 'react';
import { Box, CircularProgress, Typography } from '@mui/material';

const LoadingScreen = ({ message = 'Loading...' }) => (
  <Box
    sx={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: '100vh', gap: 2,
      background: 'linear-gradient(135deg, #1976d2 0%, #0d47a1 100%)',
    }}
  >
    <CircularProgress size={56} sx={{ color: '#fff' }} />
    <Typography variant="h6" sx={{ color: '#fff', fontWeight: 500 }}>{message}</Typography>
  </Box>
);

export default LoadingScreen;
