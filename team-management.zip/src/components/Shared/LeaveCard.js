import React, { useState } from 'react';
import {
  Card, CardContent, Box, Typography, Chip, Button, Avatar, Tooltip,
  TextField, Collapse,
} from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import EventIcon from '@mui/icons-material/Event';
import { getStatusColor, formatDate } from '../../utils/helpers';

const LeaveCard = ({ leave, user, canReview, canCancel, onApprove, onReject, onCancel }) => {
  const [showReview, setShowReview] = useState(false);
  const [comments, setComments] = useState('');
  const [action, setAction] = useState(null);

  const handleAction = (type) => { setAction(type); setShowReview(true); };
  const handleSubmit = () => {
    if (action === 'approve') onApprove(leave.id, comments);
    else onReject(leave.id, comments);
    setShowReview(false);
    setComments('');
  };

  return (
    <Card elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2, mb: 1.5 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            {user && (
              <Avatar sx={{ bgcolor: '#1976d2', width: 36, height: 36, fontSize: 12 }}>{user.avatar}</Avatar>
            )}
            <Box>
              <Typography fontWeight={600}>{user?.name || 'Unknown'}</Typography>
              <Typography variant="caption" color="text.secondary">{user?.department}</Typography>
            </Box>
          </Box>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Chip label={leave.type} size="small" variant="outlined" />
            <Chip label={leave.status} size="small" color={getStatusColor(leave.status)} />
          </Box>
        </Box>
        <Box sx={{ display: 'flex', gap: 2, mt: 1.5, flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <EventIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            <Typography variant="body2">{formatDate(leave.startDate)} — {formatDate(leave.endDate)}</Typography>
          </Box>
          <Typography variant="body2" sx={{ bgcolor: '#f0f7ff', px: 1, borderRadius: 1, color: '#1976d2', fontWeight: 600 }}>
            {leave.days} day{leave.days > 1 ? 's' : ''}
          </Typography>
        </Box>
        {leave.reason && (
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1, fontStyle: 'italic' }}>"{leave.reason}"</Typography>
        )}
        {leave.comments && leave.status !== 'Pending' && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
            Comment: {leave.comments}
          </Typography>
        )}
        {(canReview && leave.status === 'Pending') || (canCancel && leave.status === 'Pending') ? (
          <Box sx={{ display: 'flex', gap: 1, mt: 1.5, flexWrap: 'wrap' }}>
            {canReview && leave.status === 'Pending' && (
              <>
                <Button size="small" variant="contained" color="success" startIcon={<CheckIcon />} onClick={() => handleAction('approve')}>Approve</Button>
                <Button size="small" variant="outlined" color="error" startIcon={<CloseIcon />} onClick={() => handleAction('reject')}>Reject</Button>
              </>
            )}
            {canCancel && leave.status === 'Pending' && (
              <Button size="small" variant="outlined" color="error" startIcon={<DeleteIcon />} onClick={() => onCancel(leave.id)}>Cancel</Button>
            )}
          </Box>
        ) : null}
        <Collapse in={showReview}>
          <Box sx={{ mt: 1.5, display: 'flex', gap: 1, alignItems: 'flex-end' }}>
            <TextField size="small" fullWidth label="Comments (optional)" value={comments}
              onChange={(e) => setComments(e.target.value)} multiline rows={2} />
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
              <Button size="small" variant="contained" color={action === 'approve' ? 'success' : 'error'} onClick={handleSubmit}>
                Confirm
              </Button>
              <Button size="small" onClick={() => setShowReview(false)}>Cancel</Button>
            </Box>
          </Box>
        </Collapse>
      </CardContent>
    </Card>
  );
};

export default LeaveCard;
