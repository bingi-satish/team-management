import React from 'react';
import { Card, CardContent, Box, Typography, Chip, Avatar, Tooltip, IconButton, LinearProgress } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { getPriorityColor, getStatusColor, getDaysUntilDue, formatDate } from '../../utils/helpers';

const TaskCard = ({ task, assignee, onEdit, onDelete, canEdit }) => {
  const days = getDaysUntilDue(task.dueDate);
  const isOverdue = days < 0 && task.status !== 'Completed' && task.status !== 'Cancelled';
  const isDueSoon = days >= 0 && days <= 2 && task.status !== 'Completed';

  return (
    <Card elevation={0} sx={{
      border: isOverdue ? '1px solid #ffcdd2' : '1px solid #e8ecf4',
      borderRadius: 2, mb: 1.5,
      bgcolor: isOverdue ? '#fff8f8' : '#fff',
      transition: 'box-shadow 0.2s',
      '&:hover': { boxShadow: '0 2px 12px rgba(0,0,0,0.1)' },
    }}>
      <CardContent sx={{ pb: '12px !important' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Typography variant="body1" fontWeight={600} sx={{ flex: 1, pr: 1 }}>{task.title}</Typography>
          {canEdit && (
            <Box>
              <Tooltip title="Edit"><IconButton size="small" onClick={() => onEdit(task)} sx={{ p: 0.5 }}><EditIcon fontSize="small" /></IconButton></Tooltip>
              <Tooltip title="Delete"><IconButton size="small" onClick={() => onDelete(task)} color="error" sx={{ p: 0.5 }}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
            </Box>
          )}
        </Box>
        {task.description && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5, mb: 1 }}>{task.description}</Typography>
        )}
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 1 }}>
          <Chip label={task.priority} size="small" color={getPriorityColor(task.priority)} />
          <Chip label={task.status} size="small" color={getStatusColor(task.status)} variant="outlined" />
          {task.project && <Chip label={task.project} size="small" variant="outlined" />}
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 1 }}>
          {assignee && (
            <Tooltip title={assignee.name}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Avatar sx={{ width: 22, height: 22, fontSize: 9, bgcolor: '#1976d2' }}>{assignee.avatar}</Avatar>
                <Typography variant="caption" color="text.secondary">{assignee.name}</Typography>
              </Box>
            </Tooltip>
          )}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            {isOverdue ? (
              <WarningAmberIcon sx={{ fontSize: 14, color: 'error.main' }} />
            ) : (
              <AccessTimeIcon sx={{ fontSize: 14, color: isDueSoon ? 'warning.main' : 'text.disabled' }} />
            )}
            <Typography variant="caption" sx={{ color: isOverdue ? 'error.main' : isDueSoon ? 'warning.main' : 'text.secondary' }}>
              {isOverdue ? `${Math.abs(days)}d overdue` : days === 0 ? 'Due today' : `Due ${formatDate(task.dueDate)}`}
            </Typography>
          </Box>
        </Box>
        {task.tags?.length > 0 && (
          <Box sx={{ display: 'flex', gap: 0.5, mt: 0.5, flexWrap: 'wrap' }}>
            {task.tags.map((tag) => <Chip key={tag} label={`#${tag}`} size="small" sx={{ height: 16, fontSize: 10, bgcolor: '#f0f7ff', color: '#1976d2' }} />)}
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default TaskCard;
