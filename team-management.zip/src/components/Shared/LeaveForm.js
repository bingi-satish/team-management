import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
  Grid, TextField, MenuItem, FormControl, InputLabel, Select, FormHelperText, Typography, Box,
} from '@mui/material';
import { LEAVE_TYPES } from '../../utils/constants';
import { getLeaveBalance } from '../../utils/helpers';

const defaultForm = { type: 'Annual', startDate: '', endDate: '', reason: '' };

const LeaveForm = ({ open, onClose, onSubmit, currentUser, leaves }) => {
  const [form, setForm] = useState(defaultForm);
  const [errors, setErrors] = useState({});
  const balance = getLeaveBalance(leaves, currentUser?.id);

  useEffect(() => { setForm(defaultForm); setErrors({}); }, [open]);

  const validate = () => {
    const e = {};
    if (!form.type) e.type = 'Leave type is required.';
    if (!form.startDate) e.startDate = 'Start date is required.';
    if (!form.endDate) e.endDate = 'End date is required.';
    else if (new Date(form.endDate) < new Date(form.startDate)) e.endDate = 'End date must be after start date.';
    if (!form.reason.trim()) e.reason = 'Reason is required.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit({ ...form, userId: currentUser.id });
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle fontWeight={700}>Request Leave</DialogTitle>
      <DialogContent dividers>
        <Box sx={{ display: 'flex', gap: 2, mb: 2, p: 1.5, bgcolor: '#f0f7ff', borderRadius: 1 }}>
          {['Annual', 'Sick', 'Casual'].map((type) => (
            <Box key={type} sx={{ textAlign: 'center', flex: 1 }}>
              <Typography variant="h6" fontWeight={700} color="primary">{balance[type]}</Typography>
              <Typography variant="caption" color="text.secondary">{type} Left</Typography>
            </Box>
          ))}
        </Box>
        <Grid container spacing={2} sx={{ pt: 1 }}>
          <Grid item xs={12}>
            <FormControl fullWidth error={!!errors.type} required>
              <InputLabel>Leave Type</InputLabel>
              <Select value={form.type} onChange={handleChange('type')} label="Leave Type">
                {LEAVE_TYPES.map((t) => <MenuItem key={t} value={t}>{t}</MenuItem>)}
              </Select>
              {errors.type && <FormHelperText>{errors.type}</FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <TextField fullWidth label="Start Date" type="date" value={form.startDate} onChange={handleChange('startDate')}
              error={!!errors.startDate} helperText={errors.startDate} InputLabelProps={{ shrink: true }} required />
          </Grid>
          <Grid item xs={6}>
            <TextField fullWidth label="End Date" type="date" value={form.endDate} onChange={handleChange('endDate')}
              error={!!errors.endDate} helperText={errors.endDate} InputLabelProps={{ shrink: true }} required />
          </Grid>
          <Grid item xs={12}>
            <TextField fullWidth label="Reason" value={form.reason} onChange={handleChange('reason')}
              multiline rows={3} error={!!errors.reason} helperText={errors.reason} required />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose} variant="outlined">Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">Submit Request</Button>
      </DialogActions>
    </Dialog>
  );
};

export default LeaveForm;
