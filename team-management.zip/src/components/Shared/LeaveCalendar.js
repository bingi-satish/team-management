import React, { useState } from 'react';
import { Box, Typography, Paper, Grid, Chip, Tooltip, IconButton } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const LeaveCalendar = ({ leaves, users }) => {
  const [date, setDate] = useState(new Date());
  const year = date.getFullYear();
  const month = date.getMonth();

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const approvedLeaves = leaves.filter((l) => l.status === 'Approved');

  const getLeavesOnDay = (day) => {
    const d = new Date(year, month, day);
    return approvedLeaves.filter((l) => {
      const start = new Date(l.startDate);
      const end = new Date(l.endDate);
      start.setHours(0, 0, 0, 0); end.setHours(0, 0, 0, 0); d.setHours(0, 0, 0, 0);
      return d >= start && d <= end;
    });
  };

  const getUserName = (userId) => users.find((u) => u.id === userId)?.name || 'Unknown';
  const today = new Date();

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let i = 1; i <= daysInMonth; i++) cells.push(i);

  return (
    <Paper elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2, p: 2 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <IconButton size="small" onClick={() => setDate(new Date(year, month - 1, 1))}><ChevronLeftIcon /></IconButton>
        <Typography fontWeight={700} variant="h6">{MONTHS[month]} {year}</Typography>
        <IconButton size="small" onClick={() => setDate(new Date(year, month + 1, 1))}><ChevronRightIcon /></IconButton>
      </Box>
      <Grid container>
        {DAYS.map((d) => (
          <Grid item xs={12 / 7} key={d} sx={{ textAlign: 'center', py: 0.5 }}>
            <Typography variant="caption" fontWeight={700} color="text.secondary">{d}</Typography>
          </Grid>
        ))}
        {cells.map((day, idx) => {
          const dayLeaves = day ? getLeavesOnDay(day) : [];
          const isToday = day && today.getDate() === day && today.getMonth() === month && today.getFullYear() === year;
          return (
            <Grid item xs={12 / 7} key={idx} sx={{ minHeight: 64, border: '1px solid #f0f0f0', p: 0.5, bgcolor: isToday ? '#e3f2fd' : 'transparent' }}>
              {day && (
                <>
                  <Typography variant="caption" fontWeight={isToday ? 700 : 400} color={isToday ? 'primary' : 'text.primary'}>
                    {day}
                  </Typography>
                  {dayLeaves.slice(0, 2).map((l) => (
                    <Tooltip key={l.id} title={`${getUserName(l.userId)} - ${l.type}`}>
                      <Box sx={{ bgcolor: '#bbdefb', borderRadius: 0.5, px: 0.5, mt: 0.3, overflow: 'hidden' }}>
                        <Typography variant="caption" noWrap sx={{ fontSize: 9, color: '#0d47a1', display: 'block' }}>
                          {getUserName(l.userId)}
                        </Typography>
                      </Box>
                    </Tooltip>
                  ))}
                  {dayLeaves.length > 2 && (
                    <Typography variant="caption" sx={{ fontSize: 9, color: 'text.secondary' }}>+{dayLeaves.length - 2} more</Typography>
                  )}
                </>
              )}
            </Grid>
          );
        })}
      </Grid>
    </Paper>
  );
};

export default LeaveCalendar;
