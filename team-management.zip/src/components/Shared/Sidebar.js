import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText,
  Toolbar, Box, Typography, Divider, Avatar, Chip,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import AssignmentIcon from '@mui/icons-material/Assignment';
import EventNoteIcon from '@mui/icons-material/EventNote';
import PersonIcon from '@mui/icons-material/Person';
import { useAuth } from '../../contexts/AuthContext';
import { ROLES, ROUTES } from '../../utils/constants';

const DRAWER_WIDTH = 240;

const navItems = [
  { label: 'Dashboard', icon: <DashboardIcon />, path: ROUTES.DASHBOARD, roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.ASSOCIATE] },
  { label: 'Users', icon: <PeopleIcon />, path: ROUTES.USERS, roles: [ROLES.ADMIN] },
  { label: 'Tasks', icon: <AssignmentIcon />, path: ROUTES.TASKS, roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.ASSOCIATE] },
  { label: 'Leaves', icon: <EventNoteIcon />, path: ROUTES.LEAVES, roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.ASSOCIATE] },
  { label: 'Profile', icon: <PersonIcon />, path: ROUTES.PROFILE, roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.ASSOCIATE] },
];

const roleColors = { Admin: 'error', Manager: 'warning', Associate: 'info' };

const Sidebar = ({ mobileOpen, onClose }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const filtered = navItems.filter((item) => item.roles.includes(user?.role));

  const content = (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Toolbar sx={{ background: 'linear-gradient(135deg, #1976d2, #0d47a1)', flexDirection: 'column', py: 2.5, gap: 1 }}>
        <Typography variant="h6" sx={{ color: '#fff', fontWeight: 700, letterSpacing: 0.5 }}>
          TeamSync
        </Typography>
        <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.7)' }}>
          Management Portal
        </Typography>
      </Toolbar>
      <Box sx={{ px: 2, py: 2, bgcolor: '#f8faff', borderBottom: '1px solid #e0e7ff' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Avatar sx={{ bgcolor: '#1976d2', width: 40, height: 40, fontSize: 14, fontWeight: 700 }}>
            {user?.avatar}
          </Avatar>
          <Box>
            <Typography variant="body2" fontWeight={600} noWrap>{user?.name}</Typography>
            <Chip label={user?.role} size="small" color={roleColors[user?.role]} sx={{ height: 18, fontSize: 10 }} />
          </Box>
        </Box>
      </Box>
      <Divider />
      <List sx={{ flex: 1, px: 1, py: 1 }}>
        {filtered.map((item) => {
          const active = location.pathname === item.path;
          return (
            <ListItem key={item.path} disablePadding sx={{ mb: 0.5 }}>
              <ListItemButton
                selected={active}
                onClick={() => { navigate(item.path); onClose?.(); }}
                sx={{
                  borderRadius: 2,
                  '&.Mui-selected': { bgcolor: '#e3f2fd', color: '#1976d2', '& .MuiListItemIcon-root': { color: '#1976d2' } },
                  '&:hover': { bgcolor: '#f0f7ff' },
                }}
              >
                <ListItemIcon sx={{ minWidth: 36, color: active ? '#1976d2' : 'text.secondary' }}>
                  {item.icon}
                </ListItemIcon>
                <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: 14, fontWeight: active ? 600 : 400 }} />
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>
      <Box sx={{ p: 2, borderTop: '1px solid #eee' }}>
        <Typography variant="caption" color="text.secondary">
          v{process.env.REACT_APP_VERSION}
        </Typography>
      </Box>
    </Box>
  );

  return (
    <Box component="nav" sx={{ width: { md: DRAWER_WIDTH }, flexShrink: { md: 0 } }}>
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={onClose}
        ModalProps={{ keepMounted: true }}
        sx={{ display: { xs: 'block', md: 'none' }, '& .MuiDrawer-paper': { width: DRAWER_WIDTH } }}
      >
        {content}
      </Drawer>
      <Drawer
        variant="permanent"
        sx={{ display: { xs: 'none', md: 'block' }, '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' } }}
        open
      >
        {content}
      </Drawer>
    </Box>
  );
};

export { DRAWER_WIDTH };
export default Sidebar;
