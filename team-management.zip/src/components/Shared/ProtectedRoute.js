import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { ROUTES } from '../../utils/constants';

// AuthProvider already shows LoadingScreen while MSAL resolves,
// so by the time ProtectedRoute renders, loading is always false.
const ProtectedRoute = ({ children, roles }) => {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to={ROUTES.UNAUTHORIZED} replace />;
  return children;
};

export default ProtectedRoute;
