import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Grid,
  TextField, MenuItem, FormControl, InputLabel, Select, Chip, Box, FormHelperText,
} from '@mui/material';
import { TASK_STATUS, TASK_PRIORITY } from '../../utils/constants';

const defaultForm = { title: '', description: '', assignedTo: '', status: TASK_STATUS.PENDING, priority: TASK_PRIORITY.MEDIUM, dueDate: '', project: '', tags: [] };

const TaskForm = ({ open, onClose, onSubmit, initialData, users, currentUser }) => {
  const [form, setForm] = useState(defaultForm);
  const [errors, setErrors] = useState({});
  const [tagInput, setTagInput] = useState('');

  useEffect(() => {
    if (initialData) setForm({ ...defaultForm, ...initialData, assignedTo: initialData.assignedTo || '', tags: initialData.tags || [] });
    else setForm(defaultForm);
    setErrors({});
    setTagInput('');
  }, [initialData, open]);

  const validate = () => {
    const e = {};
    if (!form.title.trim()) e.title = 'Title is required.';
    if (!form.assignedTo) e.assignedTo = 'Please assign this task.';
    if (!form.dueDate) e.dueDate = 'Due date is required.';
    if (!form.project.trim()) e.project = 'Project is required.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const addTag = (e) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      setForm((f) => ({ ...f, tags: [...new Set([...f.tags, tagInput.trim()])] }));
      setTagInput('');
    }
  };

  const removeTag = (tag) => setForm((f) => ({ ...f, tags: f.tags.filter((t) => t !== tag) }));

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit({ ...form, assignedTo: Number(form.assignedTo), assignedBy: currentUser.id });
  };

  const assignableUsers = users?.filter((u) => u.status === 'Active') || [];

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle fontWeight={700}>{initialData ? 'Edit Task' : 'Create Task'}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ pt: 1 }}>
          <Grid item xs={12}>
            <TextField fullWidth label="Task Title" value={form.title} onChange={handleChange('title')}
              error={!!errors.title} helperText={errors.title} required />
          </Grid>
          <Grid item xs={12}>
            <TextField fullWidth label="Description" value={form.description} onChange={handleChange('description')}
              multiline rows={3} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.assignedTo} required>
              <InputLabel>Assign To</InputLabel>
              <Select value={form.assignedTo} onChange={handleChange('assignedTo')} label="Assign To">
                {assignableUsers.map((u) => <MenuItem key={u.id} value={u.id}>{u.name} ({u.role})</MenuItem>)}
              </Select>
              {errors.assignedTo && <FormHelperText>{errors.assignedTo}</FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="Project" value={form.project} onChange={handleChange('project')}
              error={!!errors.project} helperText={errors.project} required />
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel>Status</InputLabel>
              <Select value={form.status} onChange={handleChange('status')} label="Status">
                {Object.values(TASK_STATUS).map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel>Priority</InputLabel>
              <Select value={form.priority} onChange={handleChange('priority')} label="Priority">
                {Object.values(TASK_PRIORITY).map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField fullWidth label="Due Date" type="date" value={form.dueDate} onChange={handleChange('dueDate')}
              error={!!errors.dueDate} helperText={errors.dueDate} InputLabelProps={{ shrink: true }} required />
          </Grid>
          <Grid item xs={12}>
            <TextField fullWidth label="Add Tags (press Enter)" value={tagInput}
              onChange={(e) => setTagInput(e.target.value)} onKeyDown={addTag}
              placeholder="e.g. frontend, urgent" />
            {form.tags.length > 0 && (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 1 }}>
                {form.tags.map((tag) => (
                  <Chip key={tag} label={tag} size="small" onDelete={() => removeTag(tag)} />
                ))}
              </Box>
            )}
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose} variant="outlined">Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">{initialData ? 'Update' : 'Create'}</Button>
      </DialogActions>
    </Dialog>
  );
};

export default TaskForm;
