import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Grid,
  TextField, MenuItem, FormControl, InputLabel, Select, FormHelperText,
} from '@mui/material';
import { ROLES, DEPARTMENTS, USER_STATUS } from '../../utils/constants';

const defaultForm = { name: '', email: '', role: ROLES.ASSOCIATE, department: '', phone: '', status: USER_STATUS.ACTIVE, managerId: '', joinDate: '' };

const UserForm = ({ open, onClose, onSubmit, initialData, users }) => {
  const [form, setForm] = useState(defaultForm);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialData) setForm({ ...defaultForm, ...initialData, managerId: initialData.managerId || '' });
    else setForm(defaultForm);
    setErrors({});
  }, [initialData, open]);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Name is required.';
    if (!form.email.trim()) e.email = 'Email is required.';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Invalid email.';
    if (!form.role) e.role = 'Role is required.';
    if (!form.department) e.department = 'Department is required.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit({ ...form, managerId: form.managerId ? Number(form.managerId) : null });
  };

  const managers = users?.filter((u) => u.role === ROLES.MANAGER || u.role === ROLES.ADMIN) || [];

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle fontWeight={700}>{initialData ? 'Edit User' : 'Add New User'}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ pt: 1 }}>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="Full Name" value={form.name} onChange={handleChange('name')}
              error={!!errors.name} helperText={errors.name} required />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="Email" type="email" value={form.email} onChange={handleChange('email')}
              error={!!errors.email} helperText={errors.email} required />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.role} required>
              <InputLabel>Role</InputLabel>
              <Select value={form.role} onChange={handleChange('role')} label="Role">
                {Object.values(ROLES).map((r) => <MenuItem key={r} value={r}>{r}</MenuItem>)}
              </Select>
              {errors.role && <FormHelperText>{errors.role}</FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.department} required>
              <InputLabel>Department</InputLabel>
              <Select value={form.department} onChange={handleChange('department')} label="Department">
                {DEPARTMENTS.map((d) => <MenuItem key={d} value={d}>{d}</MenuItem>)}
              </Select>
              {errors.department && <FormHelperText>{errors.department}</FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="Phone" value={form.phone} onChange={handleChange('phone')} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>Status</InputLabel>
              <Select value={form.status} onChange={handleChange('status')} label="Status">
                {Object.values(USER_STATUS).map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>Manager</InputLabel>
              <Select value={form.managerId} onChange={handleChange('managerId')} label="Manager">
                <MenuItem value="">None</MenuItem>
                {managers.map((m) => <MenuItem key={m.id} value={m.id}>{m.name}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="Join Date" type="date" value={form.joinDate} onChange={handleChange('joinDate')}
              InputLabelProps={{ shrink: true }} />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose} variant="outlined">Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">{initialData ? 'Update' : 'Create'}</Button>
      </DialogActions>
    </Dialog>
  );
};

export default UserForm;
