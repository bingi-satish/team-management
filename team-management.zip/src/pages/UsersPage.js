import React, { useEffect, useState } from 'react';
import { Box, Button, LinearProgress, Alert, Grid } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import PeopleIcon from '@mui/icons-material/People';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import useNotification from '../hooks/useNotification';
import PageHeader from '../components/Shared/PageHeader';
import StatCard from '../components/Shared/StatCard';
import UserTable from '../components/Admin/UserTable';
import UserForm from '../components/Admin/UserForm';
import ConfirmDialog from '../components/Shared/ConfirmDialog';
import { ROLES } from '../utils/constants';

const UsersPage = () => {
  const { users, fetchUsers, createUser, updateUser, deleteUser, loading, errors } = useApp();
  const { user: currentUser } = useAuth();
  const notify = useNotification();

  const [formOpen, setFormOpen] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  useEffect(() => { fetchUsers(); }, []);

  const handleCreate = async (data) => {
    try {
      await createUser(data);
      notify.success('User created successfully!');
      setFormOpen(false);
    } catch (e) { notify.error(e.message); }
  };

  const handleUpdate = async (data) => {
    try {
      await updateUser(editUser.id, data);
      notify.success('User updated successfully!');
      setEditUser(null);
    } catch (e) { notify.error(e.message); }
  };

  const handleDelete = async () => {
    try {
      await deleteUser(deleteTarget.id);
      notify.success('User deleted.');
      setDeleteTarget(null);
    } catch (e) { notify.error(e.message); }
  };

  const stats = {
    total: users.length,
    active: users.filter((u) => u.status === 'Active').length,
    managers: users.filter((u) => u.role === ROLES.MANAGER).length,
    associates: users.filter((u) => u.role === ROLES.ASSOCIATE).length,
  };

  if (loading.users) return <Box><LinearProgress /></Box>;

  return (
    <Box>
      <PageHeader
        title="User Management"
        subtitle={`${stats.total} total users across all departments`}
        action={
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => setFormOpen(true)}>
            Add User
          </Button>
        }
      />

      {errors.users && <Alert severity="error" sx={{ mb: 2 }}>{errors.users}</Alert>}

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={3}><StatCard title="Total Users" value={stats.total} icon={<PeopleIcon />} color="primary" /></Grid>
        <Grid item xs={6} sm={3}><StatCard title="Active" value={stats.active} icon={<PeopleIcon />} color="success" /></Grid>
        <Grid item xs={6} sm={3}><StatCard title="Managers" value={stats.managers} icon={<PeopleIcon />} color="warning" /></Grid>
        <Grid item xs={6} sm={3}><StatCard title="Associates" value={stats.associates} icon={<PeopleIcon />} color="info" /></Grid>
      </Grid>

      <UserTable
        users={users}
        onEdit={(u) => setEditUser(u)}
        onDelete={(u) => setDeleteTarget(u)}
      />

      <UserForm
        open={formOpen || !!editUser}
        onClose={() => { setFormOpen(false); setEditUser(null); }}
        onSubmit={editUser ? handleUpdate : handleCreate}
        initialData={editUser}
        users={users}
      />

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete User"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone.`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        confirmText="Delete"
      />
    </Box>
  );
};

export default UsersPage;
