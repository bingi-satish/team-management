import React, { useEffect, useState } from 'react';
import {
  Box, Button, LinearProgress, Alert, Grid, Tabs, Tab,
  FormControl, InputLabel, Select, MenuItem, Chip,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EventNoteIcon from '@mui/icons-material/EventNote';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import useNotification from '../hooks/useNotification';
import PageHeader from '../components/Shared/PageHeader';
import StatCard from '../components/Shared/StatCard';
import LeaveCard from '../components/Shared/LeaveCard';
import LeaveForm from '../components/Shared/LeaveForm';
import LeaveCalendar from '../components/Shared/LeaveCalendar';
import ConfirmDialog from '../components/Shared/ConfirmDialog';
import EmptyState from '../components/Shared/EmptyState';
import { ROLES, LEAVE_STATUS } from '../utils/constants';
import { getLeaveBalance } from '../utils/helpers';

const LeavesPage = () => {
  const { users, leaves, fetchUsers, fetchLeaves, createLeave, reviewLeave, cancelLeave, loading, errors } = useApp();
  const { user: currentUser } = useAuth();
  const notify = useNotification();

  const [tab, setTab] = useState(0);
  const [formOpen, setFormOpen] = useState(false);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [statusFilter, setStatusFilter] = useState('');

  const isAssociate = currentUser?.role === ROLES.ASSOCIATE;
  const isManager = currentUser?.role === ROLES.MANAGER;
  const isAdmin = currentUser?.role === ROLES.ADMIN;

  useEffect(() => { fetchUsers(); fetchLeaves(); }, []);

  const myLeaves = leaves.filter((l) => l.userId === currentUser?.id);
  const teamLeaves = (() => {
    if (isAdmin) return leaves;
    if (isManager) {
      const teamIds = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id);
      return leaves.filter((l) => teamIds.includes(l.userId));
    }
    return myLeaves;
  })();

  const pendingLeaves = teamLeaves.filter((l) => l.status === LEAVE_STATUS.PENDING);
  const displayLeaves = (tab === 0 ? (isAssociate ? myLeaves : pendingLeaves) : teamLeaves)
    .filter((l) => !statusFilter || l.status === statusFilter);

  const balance = getLeaveBalance(leaves, currentUser?.id);

  const handleSubmit = async (data) => {
    try {
      await createLeave(data);
      notify.success('Leave request submitted successfully!');
      setFormOpen(false);
    } catch (e) { notify.error(e.message); }
  };

  const handleApprove = async (id, comments) => {
    try {
      await reviewLeave(id, LEAVE_STATUS.APPROVED, currentUser.id, comments);
      notify.success('Leave approved!');
    } catch (e) { notify.error(e.message); }
  };

  const handleReject = async (id, comments) => {
    try {
      await reviewLeave(id, LEAVE_STATUS.REJECTED, currentUser.id, comments);
      notify.warning('Leave rejected.');
    } catch (e) { notify.error(e.message); }
  };

  const handleCancel = async () => {
    try {
      await cancelLeave(cancelTarget);
      notify.info('Leave request cancelled.');
      setCancelTarget(null);
    } catch (e) { notify.error(e.message); }
  };

  if (loading.leaves) return <Box><LinearProgress /></Box>;

  return (
    <Box>
      <PageHeader
        title="Leave Management"
        subtitle={isAssociate ? 'Track and manage your leaves' : `${pendingLeaves.length} pending approvals`}
        action={
          isAssociate && (
            <Button variant="contained" startIcon={<AddIcon />} onClick={() => setFormOpen(true)}>
              Request Leave
            </Button>
          )
        }
      />

      {errors.leaves && <Alert severity="error" sx={{ mb: 2 }}>{errors.leaves}</Alert>}

      {/* Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {isAssociate ? (
          <>
            <Grid item xs={6} sm={3}><StatCard title="Annual Left" value={balance.Annual} icon={<EventNoteIcon />} color="primary" subtitle="of 20 days" /></Grid>
            <Grid item xs={6} sm={3}><StatCard title="Sick Left" value={balance.Sick} icon={<EventNoteIcon />} color="info" subtitle="of 10 days" /></Grid>
            <Grid item xs={6} sm={3}><StatCard title="Casual Left" value={balance.Casual} icon={<EventNoteIcon />} color="success" subtitle="of 5 days" /></Grid>
            <Grid item xs={6} sm={3}><StatCard title="Total Requests" value={myLeaves.length} icon={<EventNoteIcon />} color="warning" /></Grid>
          </>
        ) : (
          <>
            <Grid item xs={6} sm={3}><StatCard title="Total Requests" value={teamLeaves.length} icon={<EventNoteIcon />} color="primary" /></Grid>
            <Grid item xs={6} sm={3}><StatCard title="Pending" value={pendingLeaves.length} icon={<EventNoteIcon />} color="warning" subtitle="Awaiting review" /></Grid>
            <Grid item xs={6} sm={3}><StatCard title="Approved" value={teamLeaves.filter((l) => l.status === 'Approved').length} icon={<EventNoteIcon />} color="success" /></Grid>
            <Grid item xs={6} sm={3}><StatCard title="Rejected" value={teamLeaves.filter((l) => l.status === 'Rejected').length} icon={<EventNoteIcon />} color="error" /></Grid>
          </>
        )}
      </Grid>

      {/* Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)}>
          <Tab label={isAssociate ? 'My Requests' : `Pending (${pendingLeaves.length})`} />
          <Tab label={isAssociate ? 'History' : 'All Requests'} />
          <Tab icon={<CalendarMonthIcon fontSize="small" />} label="Calendar" iconPosition="start" />
        </Tabs>
      </Box>

      {tab === 2 ? (
        <LeaveCalendar leaves={leaves} users={users} />
      ) : (
        <>
          <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel>Status</InputLabel>
              <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} label="Status">
                <MenuItem value="">All</MenuItem>
                {Object.values(LEAVE_STATUS).map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
              </Select>
            </FormControl>
            <Chip label={`${displayLeaves.length} records`} variant="outlined" size="small" />
          </Box>

          {displayLeaves.length === 0 ? (
            <EmptyState
              title="No leave requests found"
              subtitle={isAssociate ? "You haven't submitted any leave requests yet." : "No requests match your filters."}
              action={isAssociate ? () => setFormOpen(true) : undefined}
              actionLabel="Request Leave"
            />
          ) : (
            <Grid container spacing={2}>
              {displayLeaves.map((leave) => (
                <Grid item xs={12} md={6} key={leave.id}>
                  <LeaveCard
                    leave={leave}
                    user={users.find((u) => u.id === leave.userId)}
                    canReview={!isAssociate}
                    canCancel={isAssociate && leave.userId === currentUser.id}
                    onApprove={handleApprove}
                    onReject={handleReject}
                    onCancel={(id) => setCancelTarget(id)}
                  />
                </Grid>
              ))}
            </Grid>
          )}
        </>
      )}

      <LeaveForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        onSubmit={handleSubmit}
        currentUser={currentUser}
        leaves={leaves}
      />

      <ConfirmDialog
        open={!!cancelTarget}
        title="Cancel Leave Request"
        message="Are you sure you want to cancel this leave request?"
        onConfirm={handleCancel}
        onCancel={() => setCancelTarget(null)}
        confirmText="Yes, Cancel"
        confirmColor="warning"
      />
    </Box>
  );
};

export default LeavesPage;
