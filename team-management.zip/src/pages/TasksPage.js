import React, { useEffect, useState } from 'react';
import {
  Box, Button, LinearProgress, Alert, Grid, ToggleButtonGroup, ToggleButton,
  TextField, MenuItem, Select, FormControl, InputLabel, InputAdornment, Chip,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import ViewListIcon from '@mui/icons-material/ViewList';
import ViewKanbanIcon from '@mui/icons-material/ViewKanban';
import SearchIcon from '@mui/icons-material/Search';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import useNotification from '../hooks/useNotification';
import PageHeader from '../components/Shared/PageHeader';
import StatCard from '../components/Shared/StatCard';
import TaskCard from '../components/Shared/TaskCard';
import TaskForm from '../components/Shared/TaskForm';
import ConfirmDialog from '../components/Shared/ConfirmDialog';
import EmptyState from '../components/Shared/EmptyState';
import AssignmentIcon from '@mui/icons-material/Assignment';
import { ROLES, TASK_STATUS, TASK_PRIORITY } from '../utils/constants';
import { filterTasks } from '../utils/helpers';

const KANBAN_COLS = [TASK_STATUS.PENDING, TASK_STATUS.IN_PROGRESS, TASK_STATUS.COMPLETED];

const TasksPage = () => {
  const { users, tasks, fetchUsers, fetchTasks, createTask, updateTask, deleteTask, loading, errors } = useApp();
  const { user: currentUser } = useAuth();
  const notify = useNotification();

  const [view, setView] = useState('list');
  const [formOpen, setFormOpen] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [filters, setFilters] = useState({ search: '', status: '', priority: '', project: '' });

  const isAssociate = currentUser?.role === ROLES.ASSOCIATE;
  const isAdmin = currentUser?.role === ROLES.ADMIN;

  useEffect(() => { fetchUsers(); fetchTasks(); }, []);

  const visibleTasks = (() => {
    if (isAssociate) return tasks.filter((t) => t.assignedTo === currentUser.id);
    if (currentUser?.role === ROLES.MANAGER) {
      const teamIds = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id);
      return tasks.filter((t) => teamIds.includes(t.assignedTo) || t.assignedBy === currentUser.id);
    }
    return tasks;
  })();

  const filtered = filterTasks(visibleTasks, filters);
  const projects = [...new Set(tasks.map((t) => t.project).filter(Boolean))];

  const handleCreate = async (data) => {
    try {
      await createTask(data);
      notify.success('Task created!');
      setFormOpen(false);
    } catch (e) { notify.error(e.message); }
  };

  const handleUpdate = async (data) => {
    try {
      await updateTask(editTask.id, data);
      notify.success('Task updated!');
      setEditTask(null);
    } catch (e) { notify.error(e.message); }
  };

  const handleStatusChange = async (task, status) => {
    try {
      await updateTask(task.id, { status });
      notify.info(`Task marked as "${status}"`);
    } catch (e) { notify.error(e.message); }
  };

  const handleDelete = async () => {
    try {
      await deleteTask(deleteTarget.id);
      notify.success('Task deleted.');
      setDeleteTarget(null);
    } catch (e) { notify.error(e.message); }
  };

  const stats = {
    total: visibleTasks.length,
    pending: visibleTasks.filter((t) => t.status === TASK_STATUS.PENDING).length,
    inProgress: visibleTasks.filter((t) => t.status === TASK_STATUS.IN_PROGRESS).length,
    completed: visibleTasks.filter((t) => t.status === TASK_STATUS.COMPLETED).length,
  };

  if (loading.tasks) return <Box><LinearProgress /></Box>;

  return (
    <Box>
      <PageHeader
        title="Task Management"
        subtitle={`${stats.total} tasks · ${stats.inProgress} in progress`}
        action={
          !isAssociate && (
            <Button variant="contained" startIcon={<AddIcon />} onClick={() => setFormOpen(true)}>
              New Task
            </Button>
          )
        }
      />

      {errors.tasks && <Alert severity="error" sx={{ mb: 2 }}>{errors.tasks}</Alert>}

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={3}><StatCard title="Total" value={stats.total} icon={<AssignmentIcon />} color="primary" /></Grid>
        <Grid item xs={6} sm={3}><StatCard title="Pending" value={stats.pending} icon={<AssignmentIcon />} color="warning" /></Grid>
        <Grid item xs={6} sm={3}><StatCard title="In Progress" value={stats.inProgress} icon={<AssignmentIcon />} color="info" /></Grid>
        <Grid item xs={6} sm={3}><StatCard title="Completed" value={stats.completed} icon={<AssignmentIcon />} color="success" /></Grid>
      </Grid>

      {/* Filters */}
      <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
        <TextField size="small" placeholder="Search tasks..." value={filters.search}
          onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ minWidth: 200 }} />
        <FormControl size="small" sx={{ minWidth: 130 }}>
          <InputLabel>Status</InputLabel>
          <Select value={filters.status} onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))} label="Status">
            <MenuItem value="">All</MenuItem>
            {Object.values(TASK_STATUS).map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 130 }}>
          <InputLabel>Priority</InputLabel>
          <Select value={filters.priority} onChange={(e) => setFilters((f) => ({ ...f, priority: e.target.value }))} label="Priority">
            <MenuItem value="">All</MenuItem>
            {Object.values(TASK_PRIORITY).map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 160 }}>
          <InputLabel>Project</InputLabel>
          <Select value={filters.project} onChange={(e) => setFilters((f) => ({ ...f, project: e.target.value }))} label="Project">
            <MenuItem value="">All Projects</MenuItem>
            {projects.map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
          </Select>
        </FormControl>
        <Box sx={{ ml: 'auto' }}>
          <ToggleButtonGroup size="small" value={view} exclusive onChange={(_, v) => v && setView(v)}>
            <ToggleButton value="list"><ViewListIcon fontSize="small" /></ToggleButton>
            <ToggleButton value="kanban"><ViewKanbanIcon fontSize="small" /></ToggleButton>
          </ToggleButtonGroup>
        </Box>
      </Box>

      {filtered.length === 0 ? (
        <EmptyState title="No tasks found" subtitle="Try adjusting your filters or create a new task."
          action={!isAssociate ? () => setFormOpen(true) : undefined} actionLabel="Create Task" />
      ) : view === 'list' ? (
        <Grid container spacing={2}>
          {filtered.map((task) => {
            const assignee = users.find((u) => u.id === task.assignedTo);
            const canEdit = !isAssociate || (isAssociate && task.assignedTo === currentUser.id);
            return (
              <Grid item xs={12} sm={6} md={4} key={task.id}>
                <TaskCard task={task} assignee={assignee}
                  canEdit={!isAssociate}
                  onEdit={setEditTask} onDelete={setDeleteTarget} />
                {isAssociate && (
                  <Box sx={{ display: 'flex', gap: 1, mb: 1, flexWrap: 'wrap' }}>
                    {Object.values(TASK_STATUS).filter((s) => s !== task.status).map((s) => (
                      <Chip key={s} label={`Mark ${s}`} size="small" clickable
                        onClick={() => handleStatusChange(task, s)} variant="outlined" />
                    ))}
                  </Box>
                )}
              </Grid>
            );
          })}
        </Grid>
      ) : (
        // Kanban View
        <Grid container spacing={2}>
          {KANBAN_COLS.map((col) => {
            const colTasks = filtered.filter((t) => t.status === col);
            return (
              <Grid item xs={12} md={4} key={col}>
                <Box sx={{ bgcolor: '#f5f7fb', borderRadius: 2, p: 1.5 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1.5, px: 0.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box sx={{ width: 10, height: 10, borderRadius: '50%',
                        bgcolor: col === TASK_STATUS.PENDING ? '#ff9800' : col === TASK_STATUS.IN_PROGRESS ? '#2196f3' : '#4caf50' }} />
                      <Box fontWeight={600} fontSize={14}>{col}</Box>
                    </Box>
                    <Chip label={colTasks.length} size="small" />
                  </Box>
                  {colTasks.length === 0
                    ? <Box sx={{ textAlign: 'center', py: 3, color: 'text.disabled', fontSize: 13 }}>No tasks</Box>
                    : colTasks.map((task) => (
                      <TaskCard key={task.id} task={task}
                        assignee={users.find((u) => u.id === task.assignedTo)}
                        canEdit={!isAssociate}
                        onEdit={setEditTask} onDelete={setDeleteTarget} />
                    ))}
                </Box>
              </Grid>
            );
          })}
        </Grid>
      )}

      <TaskForm
        open={formOpen || !!editTask}
        onClose={() => { setFormOpen(false); setEditTask(null); }}
        onSubmit={editTask ? handleUpdate : handleCreate}
        initialData={editTask}
        users={users}
        currentUser={currentUser}
      />

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete Task"
        message={`Delete "${deleteTarget?.title}"? This cannot be undone.`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        confirmText="Delete"
      />
    </Box>
  );
};

export default TasksPage;
