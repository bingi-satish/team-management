import React from 'react';
import { Box, Typography, Button, Avatar } from '@mui/material';
import LockIcon from '@mui/icons-material/Lock';
import { useNavigate } from 'react-router-dom';
import { ROUTES } from '../utils/constants';

const UnauthorizedPage = () => {
  const navigate = useNavigate();
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '80vh', gap: 2 }}>
      <Avatar sx={{ bgcolor: 'error.light', width: 80, height: 80 }}>
        <LockIcon sx={{ fontSize: 40, color: 'error.main' }} />
      </Avatar>
      <Typography variant="h4" fontWeight={700}>Access Denied</Typography>
      <Typography variant="body1" color="text.secondary">You don't have permission to view this page.</Typography>
      <Button variant="contained" onClick={() => navigate(ROUTES.DASHBOARD)}>Back to Dashboard</Button>
    </Box>
  );
};

export default UnauthorizedPage;
