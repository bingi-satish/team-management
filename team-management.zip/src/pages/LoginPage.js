import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Box, Card, CardContent, Button, Typography, Avatar, Divider, Alert } from '@mui/material';
import WindowIcon from '@mui/icons-material/Window';
import LockIcon from '@mui/icons-material/Lock';
import { useAuth } from '../contexts/AuthContext';
import { ROUTES } from '../utils/constants';

const LoginPage = () => {
  const { user, loginWithSSO, error, clearError } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || ROUTES.DASHBOARD;

  useEffect(() => {
    if (user) navigate(from, { replace: true });
  }, [user, navigate, from]);

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #1565c0 0%, #0d47a1 50%, #1a237e 100%)',
        p: 2,
      }}
    >
      <Box sx={{ width: '100%', maxWidth: 420 }}>
        {/* Branding */}
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Avatar
            sx={{ bgcolor: 'rgba(255,255,255,0.15)', width: 72, height: 72, mx: 'auto', mb: 2 }}
          >
            <WindowIcon sx={{ fontSize: 40, color: '#fff' }} />
          </Avatar>
          <Typography variant="h4" fontWeight={700} sx={{ color: '#fff', letterSpacing: 0.5 }}>
            TeamSync
          </Typography>
          <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.65)', mt: 0.5 }}>
            {process.env.REACT_APP_APP_NAME} · Management Portal
          </Typography>
        </Box>

        <Card elevation={0} sx={{ borderRadius: 3 }}>
          <CardContent sx={{ p: 4 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
              <LockIcon color="primary" />
              <Typography variant="h6" fontWeight={700}>
                Secure Sign In
              </Typography>
            </Box>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Access is restricted to authorized organizational accounts. Sign in using
              your Windows / Microsoft credentials via your company's identity provider.
            </Typography>

            {error && (
              <Alert severity="error" sx={{ mb: 2 }} onClose={clearError}>
                {error}
              </Alert>
            )}

            {/* Single SSO button — triggers MSAL redirect */}
            <Button
              fullWidth
              variant="contained"
              size="large"
              startIcon={<WindowIcon />}
              onClick={loginWithSSO}
              sx={{
                py: 1.6,
                fontWeight: 700,
                fontSize: 15,
                background: 'linear-gradient(90deg, #0078d4, #106ebe)',
                '&:hover': { background: 'linear-gradient(90deg, #106ebe, #005a9e)' },
              }}
            >
              Sign in with Windows Authentication
            </Button>

            <Divider sx={{ my: 3 }} />

            <Box sx={{ bgcolor: '#f8faff', borderRadius: 1.5, p: 2 }}>
              <Typography variant="caption" color="text.secondary" display="block" fontWeight={600} sx={{ mb: 0.5 }}>
                How it works
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Clicking the button above will redirect you to your organization's
                identity provider (ADFS / Microsoft Entra ID). After authenticating,
                you will be returned to the portal automatically. No password is stored
                by this application.
              </Typography>
            </Box>
          </CardContent>
        </Card>

        <Typography
          variant="caption"
          sx={{ color: 'rgba(255,255,255,0.4)', display: 'block', textAlign: 'center', mt: 2.5 }}
        >
          © 2025 TeamSync · Protected by Windows Authentication (OAuth 2.0 / OIDC)
        </Typography>
      </Box>
    </Box>
  );
};

export default LoginPage;
