import React, { useEffect } from 'react';
import { Grid, Box, Typography, Card, CardContent, Chip, Avatar, LinearProgress, Alert } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import AssignmentIcon from '@mui/icons-material/Assignment';
import EventNoteIcon from '@mui/icons-material/EventNote';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import StatCard from '../components/Shared/StatCard';
import PageHeader from '../components/Shared/PageHeader';
import { ROLES } from '../utils/constants';
import { formatDate, getDaysUntilDue, getStatusColor, getPriorityColor } from '../utils/helpers';

const DashboardPage = () => {
  const { user } = useAuth();
  const { users, tasks, leaves, fetchUsers, fetchTasks, fetchLeaves, loading } = useApp();

  useEffect(() => {
    fetchUsers(); fetchTasks(); fetchLeaves();
  }, []);

  const isAdmin = user?.role === ROLES.ADMIN;
  const isManager = user?.role === ROLES.MANAGER;
  const isAssociate = user?.role === ROLES.ASSOCIATE;

  const myTasks = isAssociate ? tasks.filter((t) => t.assignedTo === user?.id) : tasks;
  const myLeaves = isAssociate ? leaves.filter((l) => l.userId === user?.id) : leaves;
  const teamTasks = isManager ? tasks.filter((t) => {
    const member = users.find((u) => u.id === t.assignedTo);
    return member?.managerId === user?.id || t.assignedBy === user?.id;
  }) : tasks;

  const pendingLeaves = leaves.filter((l) => l.status === 'Pending');
  const overdueTasks = (isAssociate ? myTasks : teamTasks).filter((t) => {
    return getDaysUntilDue(t.dueDate) < 0 && t.status !== 'Completed' && t.status !== 'Cancelled';
  });

  const dueSoonTasks = (isAssociate ? myTasks : teamTasks).filter((t) => {
    const d = getDaysUntilDue(t.dueDate);
    return d >= 0 && d <= 3 && t.status !== 'Completed';
  });

  const displayTasks = (isAssociate ? myTasks : teamTasks).slice(0, 5);
  const displayLeaves = (isManager ? pendingLeaves : myLeaves).slice(0, 4);

  if (loading.users || loading.tasks || loading.leaves) {
    return <Box sx={{ width: '100%' }}><LinearProgress /></Box>;
  }

  return (
    <Box>
      <PageHeader
        title={`Welcome back, ${user?.name?.split(' ')[0]}! 👋`}
        subtitle={`${user?.role} Dashboard · ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`}
      />

      {overdueTasks.length > 0 && (
        <Alert severity="warning" icon={<WarningAmberIcon />} sx={{ mb: 2 }}>
          You have {overdueTasks.length} overdue task{overdueTasks.length > 1 ? 's' : ''}!
          {dueSoonTasks.length > 0 && ` ${dueSoonTasks.length} more task${dueSoonTasks.length > 1 ? 's are' : ' is'} due within 3 days.`}
        </Alert>
      )}

      {/* Stat Cards */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {isAdmin && (
          <Grid item xs={6} sm={3}>
            <StatCard title="Total Users" value={users.length} icon={<PeopleIcon />} color="primary"
              subtitle={`${users.filter((u) => u.status === 'Active').length} active`} />
          </Grid>
        )}
        <Grid item xs={6} sm={isAdmin ? 3 : 4}>
          <StatCard title={isAssociate ? 'My Tasks' : 'Team Tasks'}
            value={isAssociate ? myTasks.length : teamTasks.length}
            icon={<AssignmentIcon />} color="info"
            subtitle={`${(isAssociate ? myTasks : teamTasks).filter((t) => t.status === 'In Progress').length} in progress`} />
        </Grid>
        <Grid item xs={6} sm={isAdmin ? 3 : 4}>
          <StatCard title={isManager ? 'Pending Approvals' : 'My Leaves'}
            value={isManager ? pendingLeaves.length : myLeaves.length}
            icon={<EventNoteIcon />} color={pendingLeaves.length > 0 && isManager ? 'warning' : 'success'}
            subtitle={isManager ? 'Awaiting your review' : `${myLeaves.filter((l) => l.status === 'Approved').length} approved`} />
        </Grid>
        <Grid item xs={6} sm={isAdmin ? 3 : 4}>
          <StatCard title="Completed Tasks"
            value={(isAssociate ? myTasks : teamTasks).filter((t) => t.status === 'Completed').length}
            icon={<TrendingUpIcon />} color="success"
            subtitle={`Out of ${isAssociate ? myTasks.length : teamTasks.length} total`} />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Recent Tasks */}
        <Grid item xs={12} md={7}>
          <Card elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2 }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                {isAssociate ? 'My Tasks' : 'Team Tasks'}
              </Typography>
              {displayTasks.length === 0 ? (
                <Typography color="text.secondary" variant="body2">No tasks found.</Typography>
              ) : displayTasks.map((task) => {
                const assignee = users.find((u) => u.id === task.assignedTo);
                const days = getDaysUntilDue(task.dueDate);
                const isOverdue = days < 0 && task.status !== 'Completed';
                return (
                  <Box key={task.id} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 1, borderBottom: '1px solid #f5f5f5', gap: 1 }}>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography variant="body2" fontWeight={600} noWrap>{task.title}</Typography>
                      <Box sx={{ display: 'flex', gap: 0.5, mt: 0.3, flexWrap: 'wrap' }}>
                        <Chip label={task.priority} size="small" color={getPriorityColor(task.priority)} sx={{ height: 18, fontSize: 10 }} />
                        {assignee && <Typography variant="caption" color="text.secondary">→ {assignee.name}</Typography>}
                      </Box>
                    </Box>
                    <Box sx={{ textAlign: 'right', flexShrink: 0 }}>
                      <Chip label={task.status} size="small" color={getStatusColor(task.status)} sx={{ mb: 0.3 }} />
                      <Typography variant="caption" display="block" sx={{ color: isOverdue ? 'error.main' : 'text.secondary' }}>
                        {isOverdue ? `${Math.abs(days)}d overdue` : formatDate(task.dueDate)}
                      </Typography>
                    </Box>
                  </Box>
                );
              })}
            </CardContent>
          </Card>
        </Grid>

        {/* Leave Info */}
        <Grid item xs={12} md={5}>
          <Card elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2 }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                {isManager ? 'Pending Leave Requests' : 'My Leave Requests'}
              </Typography>
              {displayLeaves.length === 0 ? (
                <Typography color="text.secondary" variant="body2">No leave requests.</Typography>
              ) : displayLeaves.map((leave) => {
                const leaveUser = users.find((u) => u.id === leave.userId);
                return (
                  <Box key={leave.id} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 1, borderBottom: '1px solid #f5f5f5' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Avatar sx={{ width: 28, height: 28, fontSize: 10, bgcolor: '#1976d2' }}>{leaveUser?.avatar}</Avatar>
                      <Box>
                        <Typography variant="body2" fontWeight={600}>{leaveUser?.name}</Typography>
                        <Typography variant="caption" color="text.secondary">{leave.type} · {leave.days}d</Typography>
                      </Box>
                    </Box>
                    <Box sx={{ textAlign: 'right' }}>
                      <Chip label={leave.status} size="small" color={getStatusColor(leave.status)} />
                      <Typography variant="caption" display="block" color="text.secondary">{formatDate(leave.startDate)}</Typography>
                    </Box>
                  </Box>
                );
              })}
            </CardContent>
          </Card>

          {/* Team Overview (Admin/Manager) */}
          {!isAssociate && (
            <Card elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2, mt: 2 }}>
              <CardContent>
                <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Team Overview</Typography>
                {users.filter((u) => isAdmin || u.managerId === user?.id).slice(0, 5).map((member) => {
                  const memberTasks = tasks.filter((t) => t.assignedTo === member.id);
                  const done = memberTasks.filter((t) => t.status === 'Completed').length;
                  const pct = memberTasks.length > 0 ? Math.round((done / memberTasks.length) * 100) : 0;
                  return (
                    <Box key={member.id} sx={{ mb: 1.5 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Avatar sx={{ width: 24, height: 24, fontSize: 9, bgcolor: '#1976d2' }}>{member.avatar}</Avatar>
                          <Typography variant="body2" fontWeight={500}>{member.name}</Typography>
                        </Box>
                        <Typography variant="caption" color="text.secondary">{done}/{memberTasks.length}</Typography>
                      </Box>
                      <LinearProgress variant="determinate" value={pct} sx={{ height: 6, borderRadius: 3 }} />
                    </Box>
                  );
                })}
              </CardContent>
            </Card>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default DashboardPage;
