import React, { useState } from 'react';
import {
  Box, Card, CardContent, Grid, Typography, Avatar, Button, TextField,
  Chip, Divider, Alert, LinearProgress, MenuItem, Select, FormControl, InputLabel,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import BusinessIcon from '@mui/icons-material/Business';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import useNotification from '../hooks/useNotification';
import PageHeader from '../components/Shared/PageHeader';
import StatCard from '../components/Shared/StatCard';
import AssignmentIcon from '@mui/icons-material/Assignment';
import EventNoteIcon from '@mui/icons-material/EventNote';
import { ROLES } from '../utils/constants';
import { formatDate, getLeaveBalance } from '../utils/helpers';
import { storage } from '../utils/storage';

const roleColors = { Admin: 'error', Manager: 'warning', Associate: 'info' };

const ProfilePage = () => {
  const { user, login } = useAuth();
  const { users, tasks, leaves, updateUser } = useApp();
  const notify = useNotification();

  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: user?.name || '', phone: user?.phone || '', department: user?.department || '' });
  const [pwForm, setPwForm] = useState({ current: '', newPw: '', confirm: '' });
  const [pwError, setPwError] = useState('');

  const myTasks = tasks.filter((t) => t.assignedTo === user?.id);
  const myLeaves = leaves.filter((l) => l.userId === user?.id);
  const balance = getLeaveBalance(leaves, user?.id);
  const manager = users.find((u) => u.id === user?.managerId);

  const handleSave = async () => {
    if (!form.name.trim()) { notify.error('Name cannot be empty.'); return; }
    setSaving(true);
    try {
      await updateUser(user.id, form);
      storage.set('user', { ...user, ...form });
      notify.success('Profile updated!');
      setEditing(false);
    } catch (e) { notify.error(e.message); }
    finally { setSaving(false); }
  };

  const handlePasswordChange = async () => {
    setPwError('');
    if (!pwForm.current || !pwForm.newPw || !pwForm.confirm) { setPwError('All fields are required.'); return; }
    if (pwForm.newPw.length < 6) { setPwError('Password must be at least 6 characters.'); return; }
    if (pwForm.newPw !== pwForm.confirm) { setPwError('Passwords do not match.'); return; }
    try {
      const userService = (await import('../services/userService')).default;
      await userService.updatePassword(user.id, pwForm.current, pwForm.newPw);
      notify.success('Password updated successfully!');
      setPwForm({ current: '', newPw: '', confirm: '' });
    } catch (e) { setPwError(e.message); }
  };

  return (
    <Box>
      <PageHeader title="My Profile" subtitle="Manage your personal information and preferences" />

      <Grid container spacing={3}>
        {/* Profile Card */}
        <Grid item xs={12} md={4}>
          <Card elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2, textAlign: 'center' }}>
            <CardContent sx={{ p: 4 }}>
              <Avatar sx={{ width: 80, height: 80, bgcolor: '#1976d2', fontSize: 28, fontWeight: 700, mx: 'auto', mb: 2 }}>
                {user?.avatar}
              </Avatar>
              <Typography variant="h6" fontWeight={700}>{user?.name}</Typography>
              <Chip label={user?.role} color={roleColors[user?.role]} size="small" sx={{ mt: 0.5, mb: 2 }} />
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, textAlign: 'left' }}>
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                  <EmailIcon fontSize="small" color="action" />
                  <Typography variant="body2">{user?.email}</Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                  <PhoneIcon fontSize="small" color="action" />
                  <Typography variant="body2">{user?.phone || '—'}</Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                  <BusinessIcon fontSize="small" color="action" />
                  <Typography variant="body2">{user?.department}</Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                  <CalendarTodayIcon fontSize="small" color="action" />
                  <Typography variant="body2">Joined {formatDate(user?.joinDate)}</Typography>
                </Box>
                {manager && (
                  <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                    <Avatar sx={{ width: 20, height: 20, fontSize: 9, bgcolor: '#1976d2' }}>{manager.avatar}</Avatar>
                    <Typography variant="body2">Reports to {manager.name}</Typography>
                  </Box>
                )}
              </Box>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Grid container spacing={1.5} sx={{ mt: 0.5 }}>
            <Grid item xs={6}><StatCard title="My Tasks" value={myTasks.length} icon={<AssignmentIcon />} color="info" /></Grid>
            <Grid item xs={6}><StatCard title="Completed" value={myTasks.filter((t) => t.status === 'Completed').length} icon={<AssignmentIcon />} color="success" /></Grid>
            <Grid item xs={6}><StatCard title="Leave Days" value={balance.Annual} icon={<EventNoteIcon />} color="primary" subtitle="Annual left" /></Grid>
            <Grid item xs={6}><StatCard title="Requests" value={myLeaves.length} icon={<EventNoteIcon />} color="warning" /></Grid>
          </Grid>
        </Grid>

        {/* Edit Profile + Password */}
        <Grid item xs={12} md={8}>
          <Card elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2, mb: 2 }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="subtitle1" fontWeight={700}>Personal Information</Typography>
                {!editing ? (
                  <Button startIcon={<EditIcon />} size="small" onClick={() => setEditing(true)}>Edit</Button>
                ) : (
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Button startIcon={<CancelIcon />} size="small" onClick={() => setEditing(false)}>Cancel</Button>
                    <Button startIcon={<SaveIcon />} variant="contained" size="small" onClick={handleSave} disabled={saving}>Save</Button>
                  </Box>
                )}
              </Box>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Full Name" value={editing ? form.name : user?.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    disabled={!editing} size="small" />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Email" value={user?.email} disabled size="small"
                    helperText="Email cannot be changed." />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Phone" value={editing ? form.phone : (user?.phone || '')}
                    onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                    disabled={!editing} size="small" />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Department" value={editing ? form.department : (user?.department || '')}
                    onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))}
                    disabled={!editing} size="small" />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Role" value={user?.role} disabled size="small"
                    helperText="Role is managed by admin." />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Status" value={user?.status} disabled size="small" />
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Change Password */}
          <Card elevation={0} sx={{ border: '1px solid #e8ecf4', borderRadius: 2 }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Change Password</Typography>
              {pwError && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setPwError('')}>{pwError}</Alert>}
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField fullWidth label="Current Password" type="password" value={pwForm.current}
                    onChange={(e) => setPwForm((f) => ({ ...f, current: e.target.value }))} size="small" />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="New Password" type="password" value={pwForm.newPw}
                    onChange={(e) => setPwForm((f) => ({ ...f, newPw: e.target.value }))} size="small" />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Confirm Password" type="password" value={pwForm.confirm}
                    onChange={(e) => setPwForm((f) => ({ ...f, confirm: e.target.value }))} size="small" />
                </Grid>
                <Grid item xs={12}>
                  <Button variant="outlined" onClick={handlePasswordChange}>Update Password</Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ProfilePage;
