# TeamSync — Team Management Application

A responsive, role-based React.js team management portal secured exclusively by **Windows Authentication (SSO)** via Microsoft MSAL (ADFS / Microsoft Entra ID).

---

## Prerequisites

- **Node.js** v18+ — [Download installer](https://nodejs.org)
- An **Azure AD / Entra ID App Registration** or **ADFS OIDC application**

---

## Quick Start

```bash
# 1. Install Node.js first (see below), then:
cd "d:\My Projects\ReactJS\team-management"
npm install
npm start
```

---

## Installing Node.js (Windows)

1. Run `D:\Softrwares\Windows\node-v24.16.0-x64.msi`
2. Follow the installer — accept defaults
3. Restart your terminal / PowerShell
4. Verify: `node -v` and `npm -v`

---

## Windows SSO Configuration

### Option A — Microsoft Entra ID (Azure AD)

1. Go to **Azure Portal → App Registrations → New Registration**
2. Name: `TeamSync`, Supported account types: *Single tenant*
3. Redirect URI: **Single-page application (SPA)** → `http://localhost:3000`
4. Copy the **Application (client) ID** and **Directory (tenant) ID**
5. Update `.env`:

```env
REACT_APP_ADFS_CLIENT_ID=<Application (client) ID>
REACT_APP_ADFS_AUTHORITY=https://login.microsoftonline.com/<Directory (tenant) ID>
REACT_APP_ADFS_REDIRECT_URI=http://localhost:3000
```

### Option B — On-Premises ADFS

1. In ADFS Management, add a new **Native Application** (OAuth2/OIDC)
2. Set redirect URI to `http://localhost:3000`
3. Update `.env`:

```env
REACT_APP_ADFS_CLIENT_ID=<your-adfs-client-id>
REACT_APP_ADFS_AUTHORITY=https://adfs.yourcompany.com/adfs
REACT_APP_ADFS_REDIRECT_URI=http://localhost:3000
```

> After login the app matches the authenticated user's email against `src/data/users.json`.
> Add your real users' AD emails to that file with the correct roles.

---

## Role-Based Access

| Role      | Access                                                       |
|-----------|--------------------------------------------------------------|
| Admin     | Full CRUD on users, all tasks & leaves, all dashboards       |
| Manager   | Assign tasks to team, approve/reject team leaves             |
| Associate | View own tasks, update task status, request leaves           |

---

## CRUD Architecture

All data is persisted in **localStorage** (simulating a database).

- On first load, `src/data/*.json` seed files are copied into localStorage.
- Every Create / Update / Delete writes an **immutable copy** back to localStorage.
- React Context (`AppContext`) keeps the UI in sync via `dispatch` after each operation.
- Passwords are stored only in localStorage and are never exposed to UI components.

### Switching to a Real Backend

Replace the service methods in `src/services/` with `axios` calls to your API.
The Context and UI layers need zero changes.

---

## Project Structure

```
src/
├── components/
│   ├── Admin/          UserForm, UserTable
│   ├── Shared/         Layout, Sidebar, Topbar, TaskCard, LeaveCard,
│   │                   LeaveCalendar, Guards, Dialogs
├── contexts/
│   ├── AuthContext.js  MSAL SSO state
│   └── AppContext.js   Users / Tasks / Leaves CRUD state
├── services/
│   ├── authService.js  MSAL wrapper (loginRedirect, logout, token)
│   ├── userService.js  CRUD → localStorage
│   ├── taskService.js  CRUD → localStorage
│   └── leaveService.js CRUD → localStorage
├── pages/
│   ├── LoginPage.js    Windows SSO button only
│   ├── DashboardPage.js
│   ├── UsersPage.js    Admin only
│   ├── TasksPage.js    List + Kanban views
│   ├── LeavesPage.js   Request / Approve / Calendar
│   └── ProfilePage.js
├── data/               Seed JSON files
└── utils/              constants, helpers, storage
```

---

## Available Scripts

| Command       | Description                  |
|---------------|------------------------------|
| `npm start`   | Dev server at localhost:3000 |
| `npm run build` | Production build to /build |
| `npm test`    | Run test suite               |
